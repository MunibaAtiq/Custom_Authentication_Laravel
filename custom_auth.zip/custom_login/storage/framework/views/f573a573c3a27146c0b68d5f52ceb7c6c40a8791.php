

<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header">Dashboard</div>
	<div class="card-body">
		
		You are Login in Laravel 9 Custom Login Registration Application.
		<p>
			<h3>Hello : <?php echo e(Auth::user()->name); ?></h3>
		</p>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom_login\custom_login\resources\views/dashboard.blade.php ENDPATH**/ ?>