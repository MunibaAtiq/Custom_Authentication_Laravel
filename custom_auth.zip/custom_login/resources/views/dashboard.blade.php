@extends('main')

@section('content')


<div class="card">
	<div class="card-header">Dashboard</div>
	<div class="card-body">
		
		You are Login in Laravel 9 Custom Login Registration Application.
		<p>
			<h3>Hello : {{ Auth::user()->name }}</h3>
		</p>
	</div>
</div>

@endsection('content')