<?php

namespace App\Http\Controllers;

use App\Models\Member;
use App\Models\User;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    //
    function show(){
        $data = User::paginate(1);
        return view('view',['members'=>$data]);
    }
}
